package crawler;

/**
 *
 * @author ehab
 */
import invertedIndex.SourceRecord;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.*;
//==============================================================================

public class WebCrawlerWithDepth {
    private static final int MAX_DEPTH =2;
    private static final int MAX_PER_PAGE = 6;
    int max_docs = 20;
    private HashSet<String> links;
    Map<Integer, SourceRecord> sources;
    //   Map<Integer, String> doc_text;
    int fid = 0;
    int plinks = 0;
    //String storageName;
//==============================================================================
    private static final int MAX_PAGES = 10;
    private Set<String> visitedPages = new HashSet<>();
    private Queue<String> pagesToVisit = new LinkedList<>();

    public void startCrawling(String[] seeds) {
        for (String seed : seeds) {
            pagesToVisit.add(seed);
        }

        while (!pagesToVisit.isEmpty() && visitedPages.size() < MAX_PAGES) {
            String url = pagesToVisit.poll();
            if (visitedPages.contains(url)) {
                continue;
            }

            try {
                Document doc = Jsoup.connect(url).get();
                visitedPages.add(url);
                System.out.println("Visited: " + url);

                Elements links = doc.select("a[href]");
                for (Element link : links) {
                    String absUrl = link.attr("abs:href");
                    if (absUrl.startsWith("https://en.wikipedia.org/wiki/") && !visitedPages.contains(absUrl)) {
                        pagesToVisit.add(absUrl);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Set<String> getVisitedPages() {
        return visitedPages;
    }

    private Map<String, TermInfo> index = new HashMap<>();
    private Map<Integer, String> documents = new HashMap<>();
    private int docIdCounter = 0;

    public void addDocument(String url, String content) {
        int docId = docIdCounter++;
        documents.put(docId, url);
        String[] terms = content.split("\\W+");
        Set<String> uniqueTerms = new HashSet<>(Arrays.asList(terms));

        for (String term : uniqueTerms) {
            term = term.toLowerCase();
            TermInfo termInfo = index.computeIfAbsent(term, k -> new TermInfo());
            termInfo.docFreq++;
            termInfo.postings.add(new Posting(docId, Collections.frequency(Arrays.asList(terms), term)));
        }
    }

    public double[] computeCosineSimilarity(String query, int k) {
        String[] terms = query.split("\\W+");
        double[] scores = new double[documents.size()];
        double[] docLengths = new double[documents.size()];

        for (int i = 0; i < docLengths.length; i++) {
            docLengths[i] = 1.0;
        }

        for (String term : terms) {
            term = term.toLowerCase();
            TermInfo termInfo = index.get(term);
            if (termInfo == null) continue;

            double idf = Math.log10((double) documents.size() / termInfo.docFreq);
            for (Posting posting : termInfo.postings) {
                double tfidf = (1 + Math.log10((double) posting.termFreq)) * idf;
                scores[posting.docId] += tfidf;
            }
        }

        for (int i = 0; i < scores.length; i++) {
            scores[i] /= docLengths[i];
        }

        PriorityQueue<Result> pq = new PriorityQueue<>(Comparator.comparingDouble(a -> -a.score));
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > 0) {
                pq.add(new Result(documents.get(i), scores[i]));
            }
        }

        List<Result> topKResults = new ArrayList<>();
        for (int i = 0; i < k && !pq.isEmpty(); i++) {
            topKResults.add(pq.poll());
        }

        for (Result result : topKResults) {
            System.out.println(result.url + ": " + result.score);
        }

        return scores;
    }

    private static class TermInfo {
        int docFreq = 0;
        List<Posting> postings = new ArrayList<>();
    }

    private static class Posting {
        int docId;
        int termFreq;

        Posting(int docId, int termFreq) {
            this.docId = docId;
            this.termFreq = termFreq;
        }
    }

    private static class Result {
        String url;
        double score;

        Result(String url, double score) {
            this.url = url;
            this.score = score;
        }
    }

    public WebCrawlerWithDepth() {
        links = new HashSet<>();
        sources = null;
        fid = 0;
    }

    public WebCrawlerWithDepth(invertedIndex.Index5 in) {
        links = new HashSet<>();
        sources = in.sources;
        fid = 0;
    }

    public void setSources(invertedIndex.Index5 in) {
        sources = in.sources;
    }
//==============================================================================

    public String getText(Document document) {
        String pAcc = "";
        Elements p = document.body().getElementsByTag("p");

        for (Element e : p) {
            pAcc += e.text();
        }
        return pAcc;
    }
//==============================================================================

    public void getPageLinks(String URL, int depth, invertedIndex.Index5 index) {
       System.out.println("|| URL: [" + URL + "] --------  depth: " + depth + " fid=" + fid + " plinks=" + plinks + "\t|||| ");

        if ((!(links.contains(URL)))
                && (depth < MAX_DEPTH)
                && (fid < max_docs)
                //        && ((depth == 1) || (plinks < (MAX_PER_PAGE * (depth + 1))))
                && ((depth == 0)
                || ((depth == 1) && (plinks < ((MAX_PER_PAGE) + 290)))
                || (plinks < ((MAX_PER_PAGE * (depth + 1)) - (plinks / 2))))
                && (!URL.contains("https://.m."))
                && (URL.contains("https://en.w"))
                && (!URL.contains("wiki/Wikipedia"))
                && (!URL.contains("searchInput"))
                && (!URL.contains("wiktionary"))
                && (!URL.contains("#"))
                && (!URL.contains(","))
                && (!URL.contains("Wikiquote"))
                && (!URL.contains("disambiguation"))
                && (!URL.contains("w/index.php"))
                && (!URL.contains("wikimedia"))
                && (!URL.contains("/Privacy_policy"))
                && (!URL.contains("Geographic_coordinate_system"))
                && (!URL.contains(".org/licenses/"))
                && ((!URL.substring(12).contains(":")) || (depth == 0)) // ignor sublink that contain : bu pass the "http:"
                && (!URL.isEmpty())
                && (!URL.contains("Main_Page"))
                && (!URL.contains("mw-head"))) {
         //   try {
                //??????------------------------------------------------------------------------                
                // *** 1-  add this URL tl the  visited list
                //                links.add(URL);
                // inititailiz the document element using the Jsoup library

                
                //??????------------------------------------------------------------------------                
                // *** 2-  get all links of the page         
                // use document select  with parameter "a[href]")
                
                
                //??????------------------------------------------------------------------------
                // *** 3-  get all  paragtaphs <p></p>  elments from the page (document)

                
                //??????------------------------------------------------------------------------
                //**** 4-  get the text inside those parargraphs inside the tags <p></p>
                //***       accumulate then into  to String docText
               String docText = "";


              //****     build the sourses (given)
               //SourceRecord sr = new SourceRecord(fid, URL, document.title(), docText.substring(0, 30));
                //sr.length = docText.length();
                //sources.put(fid, sr);
                
                //??????------------------------------------------------------------------------
                //**** 5-  pass the cocText for the inverted index with the doc id
                
                
                
                plinks++;  // accumulator for thel link in a sub-branch
                fid++;   // current document id
               

               // for (Element page : linksOnPage) {
                //**** 6-  handle all the page hyper links "linksOnPage" you obtained from step 2 recursivly with depth +1
                //             Hint ::    Use  page.attr("abs:href") for each page
             //    }
                // plinks--;
       //     } catch (IOException e) {
       //         System.err.println("For '" + URL + "': " + e.getMessage());
       //     }
        }
    }
//==============================================================================

    public void parsePageLinks(String URL, int depth, invertedIndex.Index5 index) {
        System.out.println("--------------- URL: " + URL + " --------  depth: " + depth + " - - - - - - --------- ");

        plinks = 0;
        getPageLinks(URL, depth, index);
    }
//==============================================================================

    public String getSourceName(int id) {
        return sources.get(id).getURL();
    }
//==============================================================================

    void printSources() {
        for (int i = 0; i < sources.size(); i++) {
            System.out.println(">>  " + i + " [" + getSourceName(i) + "]");
        }
    }

    public invertedIndex.Index5 initializeNew(String storageName) {
        invertedIndex.Index5 index = new invertedIndex.Index5();
        setSources(index);
        index.createStore(storageName);
        return index;
    }

    public invertedIndex.Index5 initialize(String storageName) {
        invertedIndex.Index5 index = new invertedIndex.Index5();
        setSources(index);
        setDomainKnowledge(index, storageName);
        index.setN(fid);
        index.store(storageName);

        return index;
    }

    void setDomainKnowledge(invertedIndex.Index5 index, String domain) {
        if (domain.equals("test")) {
            parsePageLinks("https://en.wikipedia.org/wiki/List_of_pharaohs", 0, index);
            parsePageLinks("https://en.wikipedia.org/wiki/Cairo", 0, index);

        }

    }

//==============================================================================
    public static void main(String[] args) {


            String[] seeds = {
                    "https://en.wikipedia.org/wiki/List_of_pharaohs",
                    // Add more seed URLs if needed
            };

        WebCrawlerWithDepth crawler = new WebCrawlerWithDepth();
            crawler.startCrawling(seeds);
            Set<String> visitedPages = crawler.getVisitedPages();

        WebCrawlerWithDepth invertedIndex = new WebCrawlerWithDepth();
            for (String url : visitedPages) {
                try {
                    org.jsoup.nodes.Document doc = org.jsoup.Jsoup.connect(url).get();
                    String content = doc.body().text();
                    invertedIndex.addDocument(url, content);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            String query = "ancient egypt pharaoh";
            invertedIndex.computeCosineSimilarity(query, 10);

    }
}
